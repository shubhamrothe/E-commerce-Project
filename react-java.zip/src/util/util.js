export const handleLogout = () => {
    localStorage.clear();
}